package app;

public class Agua extends Liquido {

    public Agua () {
        setNombre("Agua");
        setEnergia(100);
        setPeso(20);
    }
    
}
