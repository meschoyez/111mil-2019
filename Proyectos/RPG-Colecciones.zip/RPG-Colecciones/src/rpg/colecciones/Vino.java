package app;

public class Vino extends Liquido {

    public Vino () {
        setNombre("Vino");
        setEnergia(30);
        setPeso(25);
    }

}
