package app;

public class Elixir extends Liquido {

    public Elixir () {
        setNombre("Elixir");
        setEnergia(300);
        setPeso(30);
    }

}
