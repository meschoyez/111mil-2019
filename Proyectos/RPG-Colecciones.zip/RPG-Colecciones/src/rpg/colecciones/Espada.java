/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg.colecciones;

/**
 *
 * @author meschoyez
 */
public class Espada extends Armas {

    public Espada () {
        setAlcance(2);
    }
    
    @Override
    public void Atacar () {
        
    }
    
    @Override
    public void RecargarArma (Objetos obj) {
        
    }    
    
}
