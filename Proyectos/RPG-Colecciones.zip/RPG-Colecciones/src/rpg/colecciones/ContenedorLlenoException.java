package rpg.colecciones;

public class ContenedorLlenoException extends Exception {
    private static final long serialVersionUID = 1L;

    public ContenedorLlenoException(String msg) {
        super(msg);
    }

}
